package com.anudip.springdemo;

public class Tea implements HotDrink  
{

	@Override
	public void preparHotDrink() {
		System.out.println("Hi ... Im preparing Hot tea for you...");
		
	}


}
