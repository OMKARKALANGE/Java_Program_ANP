package com.anudip.springdemo;

public class Restaurant 
{
	HotDrink hotDrink;
	
	String welcomenote;


	
	public void setWelcomenote(String welcomenote) {
		this.welcomenote = welcomenote;
	}

	public Restaurant(HotDrink hotDrink) 
	{
		super();
		this.hotDrink = hotDrink;
	}
	

	void prepareDrink()
	{
		hotDrink.preparHotDrink();
		
	}
	void greetCustomer() 
	{
		System.out.println(welcomenote);
	}


}
