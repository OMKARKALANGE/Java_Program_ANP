package com.anudip.springdemo;

public class Coffe implements HotDrink
{

	@Override
	public void preparHotDrink() {
		System.out.println("Hi.. Im preparing coffee for u...");

		
	}


}
