package com.anudip.springshape;

public class Rectangle implements Shape
{
	private String color;
	
	
	public void setColor(String color) 
	{
		this.color = color;
	}

	@Override
	public void draw()
	{
		System.out.println("Painter is Drawing "+color+" Rectangle");
		
	}

}
