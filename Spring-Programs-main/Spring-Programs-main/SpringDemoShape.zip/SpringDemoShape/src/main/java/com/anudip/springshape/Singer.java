package com.anudip.springshape;

public class Singer implements Performer
{

	@Override
	public void perform() 
	{
		System.out.println("Singer is Singing a song.....");
	
	}
}
