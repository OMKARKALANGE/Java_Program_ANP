package com.anudip.springshape;

public interface Shape 
{
	void draw();

}
