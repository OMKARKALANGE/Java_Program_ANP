package com.anudip.springshape;

public interface Performer 
{
	void perform();
	

}
