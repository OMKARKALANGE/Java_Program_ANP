package com.anudip.springshape;

public class Painter implements Performer 
{
	Shape shap;

	public Painter(Shape shap) 
	{
		super();
		this.shap = shap;
	}
	
	@Override
	public void perform() 
	{
		shap.draw();
		
	}

}
