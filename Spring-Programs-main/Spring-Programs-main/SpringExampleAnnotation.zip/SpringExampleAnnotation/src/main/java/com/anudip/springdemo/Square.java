package com.anudip.springdemo;

import org.springframework.stereotype.Component;

@Component("squ")
public class Square implements Shape
{
	String shadow;
	
	public Square() 
	{
		super(); 
		// TODO Auto-generated constructor stub
	}
	

	public Square(String shadow) 
	{
		super();
		this.shadow = shadow;
	}

	@Override
	public void draw() 
	{
		// TODO Auto-generated method stub	
	}

}
