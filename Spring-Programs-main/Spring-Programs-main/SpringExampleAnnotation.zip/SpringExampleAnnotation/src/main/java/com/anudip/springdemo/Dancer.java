package com.anudip.springdemo;

import org.springframework.stereotype.Component;

@Component("sakshi")

public class Dancer implements Performer
{

	@Override
	public void perform()
	{
		System.out.println("Dancer is dancing on song chintata chita chita ");
	}
	

}
