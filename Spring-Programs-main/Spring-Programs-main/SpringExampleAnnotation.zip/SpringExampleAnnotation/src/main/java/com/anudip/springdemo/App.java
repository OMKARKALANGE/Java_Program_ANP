package com.anudip.springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App  
{
    public static void main( String[] args )
    {
    	 ApplicationContext context= new ClassPathXmlApplicationContext("ShapeConfi.xml");
         // Painter p= (Painter) context.getBean("Krushna");
         // p.perform();
          
          Performer p=(Performer) context.getBean("tejas");
          p.perform(); 
    }
}
