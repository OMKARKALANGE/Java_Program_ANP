package com.anudip.springdemo;

public interface Performer 
{
	
		void perform();
	

}
