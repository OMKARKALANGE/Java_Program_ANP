package com.anudip.springdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

//There are two way to inject the object
//1) constructor 
//2) setter

@Component("tejas")
public class Painter implements Performer 
{
	@Autowired
	@Qualifier("tri")
	Shape shape;

	public Painter() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	 
	public Painter(Shape shape) 
	{
		super();
		this.shape = shape;
	}

	@Override
	public void perform() 
	{
		shape.draw();
	}
	

}
